
<?php $__env->startSection('content'); ?>

   
    
   
    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="title mb-5">
                        <h2><?php echo e($news[0]->newsTypes->news_type??""); ?></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-4">
                    <a href="<?php echo e(URL::to('/'.$nw->newsTypes->slug.'/'.$nw->slug)); ?>" class="card__article mb-5 d-block">
                        <div class="card__article-thumbnail position-relative overlay-full mb-4" style="background-image:url('<?php echo e(asset('assets/img/'.$nw["pic"])); ?>');"></div>
                        <div class="card__article-content">
                            <h3 class="text-sb-20 c-black"><?php echo e($nw->title??""); ?></h3>
                            <p class="mb-3 c-black"><?php echo strip_tags($nw->short_desc); ?></p>
                            <div class="position-relative mb-3"><label class="text-reg-12 c-black me-1"><?php echo e(Helper::getDateToString($nw->publish_on??"now")); ?></label><span class="text-reg-12 c-l-blue">Sportify</span></div>
                        </div>
                    </a>
                </div>
               
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($pageNumber<6): ?>
                <?php for($i=1;$i<=6;$i++): ?>
                <?php if($i==$pageNumber): ?>
                <?php echo e($i); ?>

                <?php else: ?>
                <a href="<?php echo e(URL::to('/'.$nw->newsTypes->slug.'?page='.$i)); ?>" ><?php echo e($i); ?></a>
                <?php endif; ?>
                <?php endfor; ?>
                <span>Next ></span>
                <?php elseif(($totalPage-6)<$pageNumber): ?>
                <span>< Prev</span>
                <?php for($i=($totalPage-6);$i<=$totalPage;$i++): ?>
                <?php if($i==$pageNumber): ?>
                <?php echo e($i); ?>

                <?php else: ?>
                <a href="<?php echo e(URL::to('/'.$nw->newsTypes->slug.'?page='.$i)); ?>" ><?php echo e($i); ?></a>
                <?php endif; ?>
                <?php endfor; ?>
                <?php else: ?>
                <span>< Prev</span>
                <?php for($i=($pageNumber-3);$i<=($pageNumber+3);$i++): ?>
                <?php if($i==$pageNumber): ?>
                <?php echo e($i); ?>

                <?php else: ?>
                <a href="<?php echo e(URL::to('/'.$nw->newsTypes->slug.'?page='.$i)); ?>" ><?php echo e($i); ?></a>
                <?php endif; ?>
                <?php endfor; ?>
                <span>Next ></span>
                <?php endif; ?>
                
            </div>
        </div>
    </section>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sportify\resources\views/pages/news/category.blade.php ENDPATH**/ ?>