<header class="header">
    <div class="header__top">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-lg-3">
                    <a href="<?php echo e(URL::to('/')); ?>" class="header__top-date">
                        <i class=""></i>
                        <p><?php echo e(date("l, d M Y")); ?></p>
                    </a>
                </div>
                <div class="col-sm-12 col-lg-6 text-center">
                    <a href="<?php echo e(URL::to('/')); ?>">
                        <img src="<?php echo e(asset('assets/images/sportify-white.svg')); ?>" class="logo" alt="">
                    </a>
                </div>
                <div class="col-sm-12 col-lg-3"></div>
            </div>
        </div>
    </div>
    <div class="header__bottom">
        <div class="container">
            <div class="row">
                <div class="col">
                    <ul>
                        <?php
                        $i=1;
                        ?>
                        <?php $__currentLoopData = Helper::header_menu(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <li><a href="<?php echo e(URL::to('/'.$nt->slug)); ?>"><?php echo e($nt->news_type??""); ?></a></li>
                        <?php
                        $i++;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
</header><?php /**PATH C:\xampp\htdocs\sportify\resources\views/layouts/header.blade.php ENDPATH**/ ?>