
<?php $__env->startSection('content'); ?>

   
    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($nw->newsLimit->count()>0): ?>
    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="title mb-5">
                        <h2><?php echo e($nw->news_type); ?></h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php for($i=0;$i<9;$i++): ?>
                <?php if(isset($nw->newsLimit[$i])): ?>
                
                <div class="col-12 col-md-4">
                    <a href="<?php echo e(URL::to('/'.$nw->slug.'/'.$nw->newsLimit[$i]->slug)); ?>" class="card__article mb-5 d-block">
                        <div class="card__article-thumbnail position-relative overlay-full mb-4" style="background-image:url('<?php echo e(asset('assets/img/'.$nw->newsLimit[$i]["pic"])); ?>');"></div>
                        <div class="card__article-content">
                            <h3 class="text-sb-20 c-black"><?php echo e($nw->newsLimit[$i]->title??""); ?></h3>
                            <p class="mb-3 c-black"><?php echo strip_tags($nw->newsLimit[$i]->short_desc); ?></p>
                            <div class="position-relative mb-3"><label class="text-reg-12 c-black me-1"><?php echo e(Helper::getDateToString($nw->newsLimit[$i]->publish_on??"now")); ?></label><span class="text-reg-12 c-l-blue">Sportify</span></div>
                        </div>
                    </a>
                </div>
                <?php else: ?>
                <?php
                $i=9;
                ?>
                <?php endif; ?>
                
                <?php endfor; ?>
            </div>
            <div class="row">
                <div class="col text-end">
                    <a href="<?php echo e(URL::to('/'.$nw->slug)); ?>" class="link">Selengkapnya ></a>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sportify\resources\views/pages/news/allcat.blade.php ENDPATH**/ ?>