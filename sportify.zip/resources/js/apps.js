'use strict'

require('./bootstrap');

// Functions
require('./functions/global');
require('./functions/slider');
require('./functions/tab');
