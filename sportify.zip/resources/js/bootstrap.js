try {
    
    window.$ = window.jQuery = require('jquery');

    require('bootstrap');
    require('slick-carousel/slick/slick.min.js');

} catch (e) {}